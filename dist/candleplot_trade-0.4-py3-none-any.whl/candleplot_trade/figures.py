# from collections import defaultdict

class figures():
    def __init__(self, df, indicator_params):
        pass
